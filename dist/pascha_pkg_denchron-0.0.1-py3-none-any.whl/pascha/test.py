from greek import calc


print(calc(2020))
