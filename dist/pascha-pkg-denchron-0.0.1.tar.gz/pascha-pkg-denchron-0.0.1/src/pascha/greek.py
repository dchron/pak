
from datetime import date

def calc(year):
    return date(year, 4, 1)
